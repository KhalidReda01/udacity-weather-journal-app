/* Global Variables */
// declare a varibale containg my own/personal api key form openWeatherMap 
const getApiKey = "297af0463ba7833c9928a95811557f3f";

// I find this in the project I just put a 1 number to adjust the month of date becausse it starts from 0 
let d = new Date();
let newDate = d.getMonth() + 1 + "." + d.getDate() + "." + d.getFullYear();
console.log(d);
console.log(newDate);

//  this is an async funtion to get the data form API to use it later 
const getDataFromApi = async (url = "") => {
  const getResponse = await fetch(url);
  try {
    const getData = await getResponse.json();
    console.log(getData);
    // print the temp from the api
    console.log(getData.main.temp);
    console.log("test get data here test ");
    const getTemp = getData.main.temp;
 

    console.log(getTemp);

    return getTemp;
  } catch (error) {
    console.log("This is an error", error);
  }
};

// get the button and add it to a varibale
const getThebutton = document.getElementById("generate");
// I get a hint to this fetch api from MDN article fetch api It's so helpful to make be understand what to do so this is a citation to not considered plagiarism and udacity forms because without the body of the post request it's not working
// the hints to use the body request because without this body the body request doens't work at all
// we create an async function to postData with 2 param one is for get url and other for the data in the post request
const postWeatherData = async (getUrl, data = {}) => {
  console.log(data);
  const PostResponse = await fetch(getUrl, {
    method: "POST",
    credentials: "same-origin",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  });
  try {
    const getData = await PostResponse.json();
    console.log(getData);
    return getData;
  } catch (error) {
    console.log("There is an error", error);
  }
};



// here I use an async fucntion to fetch ProjectData from the server 
const getDataFromServer = async (url) => {
  const getResponse = await fetch(url);
  try {
    const getUserData = await getResponse.json();
    console.log(getUserData);

  
  // here I use the regular dom method so that I can show the valid data to the user 
    const updateDate = document.getElementById('date').textContent = `Today's day is ${getUserData.date}`;

    const updatetemp = document.getElementById('temp').textContent = `Today's temperature is ${getUserData.temp}`;
    const updateContent = document.getElementById('content').textContent = `Your feeling today is ${getUserData.content}`;

  } catch (error) {
    console.log("This is an error", error);
  }
};


/*decalare a function arrow function to be speicfic that will be the second parameter on the button to be call 
when the user click on the putton after entering the zip code and his/her feeling*/


let afterClick = async () => {
 
  // get the zipcode that the user enter in our the program
  const getTheZipCode = document.getElementById("zip").value;
  console.log("It's working now");
  // declare  a variable containg the url
  const getTheUrl = `https://api.openweathermap.org/data/2.5/weather?zip=${getTheZipCode}&appid=${getApiKey}&units=metric`;
  // here I want to take the value of the zipcode input after the user click on the genereate button

  // get the user feeling today
  const getUserFeeling = document.getElementById("feelings").value;

  // here I make an if else condtiotion to check if the user left the input blank or enter a invalid us zip code and to enter a just nubmer only not string in the zip code input
  if (getTheZipCode === "" && getTheZipCode > 0) {
    alert("please enter a correct/valid us zip code");
  }
  // to ask a the user to enter how he/she is feeling today
  if (getUserFeeling === "") {
    alert("please enter how you are feeling today");
  } else  {
    //if user enter a valid data then print this in the console no need to show that to the user
    console.log(`you zip code is ${getTheZipCode} and your feeling is ${getUserFeeling} `);
  }

 
// get the tempeatrure degree form the api 
  let getTemp = await getDataFromApi(getTheUrl);
 
// here I asingn the date temp and content to the new variable that I use to show the data to user after click the button 
  // here I post the data to the server
  await postWeatherData("/testPost", {
    date: newDate,
    temp: getTemp,
    content: getUserFeeling,
  });
// here I get the the projectdata ojbect form the get 
  // and here I get it back
  await getDataFromServer("/testGet");
};
//  I think the project work now and I delted all unimortant comment and debugging code as the tutors in  the udacity formus adviced me 
// add a click event listener to the button

getThebutton.addEventListener("click", afterClick);