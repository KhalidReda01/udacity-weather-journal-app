// Setup empty JS object to act as endpoint for all routes
projectData = {};

// Require Express to run server and routes
const express = require('express');

// Start up an instance of app
const app = express();
//Require the body parser packge after intall it 
const bodyParser = require('body-parser')

/* Middleware*/
//Here we are configuring express to use body-parser as middle-ware.
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
// Require the cors package
const cors = require('cors')
// Cors for cross origin allowance
app.use(cors());

// Initialize the main project folder
app.use(express.static('website'));

const port = 8000;
// Setup Server and  have an arrow function containg the message to test the server in the terminal and use a dynamic port 
const callBackFunc = () => { console.log(`The server is working now on localhost:${port}`) };
const server = app.listen(port, callBackFunc)

//here I make a get route to get the projectDato to the user 
app.get('/testGet', (req, res) => {
    res.send(projectData)

})
// Here I make the post route 
app.post('/testPost', (req, res) => {
    // this will only work if the projectData  is a an array and this is not the case here try again to fix this you have have to deal with an oject
    // console.log(projectData.push(req.body)) 
    // console.log("what is the problem I hope it's working now I hope so ")
    // here I assign the value to put it in the project data to use it later even I can use es6 projectData={... req.body} but this way is working too 
    // projectData.temp = req.body.main
    // projectData.content = req.body.content
    // projectData.date = req.body.date
    // I tried to use the es6 to see what is going on and it works better so I left it 
    projectData = { ...req.body }
    console.log(projectData)
    // console.log("This is project Data" + projectData)
    // console.log(res.send()) 
    // here the server save the projectData 
    res.send()
    //res.end()


})

