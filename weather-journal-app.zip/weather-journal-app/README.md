# Weather-Journal App Project
 
## Project Overview
This project wants me to create an asynchronous web app that uses Web API and user data inputs to dynamically update the User inferface
## Short Summary
I modifed the `server.js` file and  modifed the  `website/app.js` file .
I setup a node environment and used the express framework . I and I used the th get and post methods ...etc but all the work is in the app.js file this file take a lot of hard work to and a lot of tires and read the articles in the MDN and and repeat the lesson in udacity classroom several times to be able to start the project .It wasn't an easy and I'm so happy that I reach that far

## About Me
My name is **Khalid** and I want to be a **Javascript/React** developer within a year from now and this project is the second step after the landing page project